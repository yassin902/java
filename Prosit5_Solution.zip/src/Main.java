public class Main {
    public static void main(String[] args) {
        // Instruction 21 : constructeurs par défaut
        Aquatic a0 = new Aquatic();
        Terrestrial t0 = new Terrestrial();
        Dolphin d0 = new Dolphin();
        Penguin p0 = new Penguin();

        // Instruction 22 : constructeurs paramétrés
        Aquatic aquatic = new Aquatic("Aquatic", "Nemo", 3, false, "mer");
        Terrestrial terrestrial = new Terrestrial("Terrestrial", "Lion", 8, true, 4);
        Dolphin dolphin = new Dolphin("Delphinidae", "Flipper", 5, true, "océan", 35.5f);
        Penguin penguin = new Penguin("Spheniscidae", "Pingu", 4, false, "bassin", 120.0f);

        // Instruction 23 : toString()
        System.out.println(aquatic);
        System.out.println(terrestrial);
        System.out.println(dolphin);
        System.out.println(penguin);

        // Instruction 24 : swim()
        aquatic.swim();
        dolphin.swim();
        penguin.swim();
    }
}
