public class Zoo {
    private String name;
    private String city;

    // Instruction 25.1 : tableau de 10 animaux aquatiques au maximum
    private Aquatic[] aquaticAnimals = new Aquatic[10];
    // nombre de cases reellement remplies
    private int nbrAquatics = 0;

    public Zoo(String name, String city) {
        this.name = name;
        this.city = city;
    }

    public String getName() {
        return name;
    }

    public String getCity() {
        return city;
    }

    // Instruction 25.2 : ajouter un animal aquatique au tableau
    public void addAquaticAnimal(Aquatic aquatic) {
        if (nbrAquatics < aquaticAnimals.length) {
            aquaticAnimals[nbrAquatics] = aquatic;
            nbrAquatics++;
        } else {
            System.out.println("Le tableau des animaux aquatiques est plein");
        }
    }

    // Instruction 26.1 : appeler swim() pour tous les animaux aquatiques
    public void makeAquaticsSwim() {
        for (int i = 0; i < nbrAquatics; i++) {
            aquaticAnimals[i].swim();
        }
    }

    // Instruction 27 : profondeur maximale des pingouins du zoo
    public float maxPenguinSwimmingDepth() {
        float max = 0;
        for (int i = 0; i < nbrAquatics; i++) {
            if (aquaticAnimals[i] instanceof Penguin) {
                Penguin p = (Penguin) aquaticAnimals[i];
                if (p.getSwimmingDepth() > max) {
                    max = p.getSwimmingDepth();
                }
            }
        }
        return max;
    }

    // Instruction 28 : nombre de dauphins et nombre de pingouins
    public void displayNumberOfAquaticsByType() {
        int nbrDolphins = 0;
        int nbrPenguins = 0;
        for (int i = 0; i < nbrAquatics; i++) {
            if (aquaticAnimals[i] instanceof Dolphin) {
                nbrDolphins++;
            } else if (aquaticAnimals[i] instanceof Penguin) {
                nbrPenguins++;
            }
        }
        System.out.println("Nombre de dauphins : " + nbrDolphins);
        System.out.println("Nombre de pingouins : " + nbrPenguins);
    }
}
