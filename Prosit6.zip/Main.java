public class Main {
    public static void main(String[] args) {
        Zoo myZoo = new Zoo("Belvedere", "Tunis");

        // Instruction 25 : ajouter plusieurs animaux aquatiques dans le zoo
        Dolphin d1 = new Dolphin("Delphinidae", "Flipper", 5, true, "Ocean", 25.5f);
        Penguin p1 = new Penguin("Spheniscidae", "Pingu", 3, false, "Antarctique", 20f);
        Penguin p2 = new Penguin("Spheniscidae", "Skipper", 4, false, "Antarctique", 35.5f);

        myZoo.addAquaticAnimal(d1);
        myZoo.addAquaticAnimal(p1);
        myZoo.addAquaticAnimal(p2);

        // Instruction 26 : appel de swim() pour tous les animaux aquatiques
        // Remarque : le tableau est de type Aquatic, mais c'est la version
        // de swim() de l'objet reel (Dolphin ou Penguin) qui s'execute
        // -> polymorphisme
        System.out.println("--- Instruction 26 ---");
        myZoo.makeAquaticsSwim();

        // Instruction 27 : profondeur maximale des pingouins
        System.out.println("--- Instruction 27 ---");
        System.out.println("Profondeur maximale des pingouins : "
                + myZoo.maxPenguinSwimmingDepth());

        // Instruction 28 : nombre par type
        System.out.println("--- Instruction 28 ---");
        myZoo.displayNumberOfAquaticsByType();

        // Instruction 31 : equals()
        System.out.println("--- Instruction 31 ---");
        Penguin p3 = new Penguin("Spheniscidae", "Pingu", 3, false, "Antarctique", 10f);
        System.out.println("p1 equals p3 : " + p1.equals(p3)); // true
        System.out.println("p1 equals p2 : " + p1.equals(p2)); // false
    }
}
