// Instruction 33.1 : exception personnalisee levee quand le zoo est plein
public class ZooFullException extends Exception {

    public ZooFullException() {
        super("Le zoo est plein, impossible d'ajouter un nouvel animal.");
    }

    public ZooFullException(String message) {
        super(message);
    }
}
