// Instruction 26.3 : la classe devient abstraite car swim() est abstraite
public abstract class Aquatic extends Animal {
    protected String habitat;

    public Aquatic() {
    }

    public Aquatic(String family, String name, int age, boolean isMammal, String habitat) {
        super(family, name, age, isMammal);
        this.habitat = habitat;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

    // Instruction 26.3 : methode abstraite -> toutes les classes filles
    // sont obligees de la redefinir
    public abstract void swim();

    // Instruction 31 : deux animaux aquatiques sont identiques s'ils ont
    // le meme name, le meme age et le meme habitat
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;                    // meme objet
        if (obj == null) return false;                   // rien a comparer
        if (getClass() != obj.getClass()) return false;  // types differents
        Aquatic other = (Aquatic) obj;
        return getAge() == other.getAge()
                && getName().equals(other.getName())
                && habitat.equals(other.habitat);
    }

    @Override
    public String toString() {
        return super.toString() + " Aquatic{habitat='" + habitat + "'}";
    }
}
