public class Zoo {
    private String name;
    private String city;

    // Animaux du zoo : une cage par animal
    private int nbrCages;
    private Animal[] animals;
    private int nbrAnimals = 0;

    // Prosit 6 : animaux aquatiques
    private Aquatic[] aquaticAnimals = new Aquatic[10];
    private int nbrAquatics = 0;

    public Zoo(String name, String city, int nbrCages) {
        this.name = name;
        this.city = city;
        this.nbrCages = nbrCages;
        this.animals = new Animal[nbrCages];
    }

    public String getName() {
        return name;
    }

    public String getCity() {
        return city;
    }

    public int getNbrCages() {
        return nbrCages;
    }

    public int getNbrAnimals() {
        return nbrAnimals;
    }

    // Instruction 32 : le type de retour passe de boolean a void
    //                  et le test "zoo plein -> return false" est supprime
    // Instruction 33 : leve ZooFullException quand le nombre max de cages est atteint
    // Instruction 34 : leve InvalidAgeException quand l'age est negatif
    public void addAnimal(Animal animal) throws ZooFullException, InvalidAgeException {
        if (animal.getAge() < 0) {
            throw new InvalidAgeException();
        }
        if (nbrAnimals >= nbrCages) {
            throw new ZooFullException();
        }
        animals[nbrAnimals] = animal;
        nbrAnimals++;
    }

    // ---------- Prosit 6 ----------

    public void addAquaticAnimal(Aquatic aquatic) {
        if (nbrAquatics < aquaticAnimals.length) {
            aquaticAnimals[nbrAquatics] = aquatic;
            nbrAquatics++;
        } else {
            System.out.println("Le tableau des animaux aquatiques est plein");
        }
    }

    public void makeAquaticsSwim() {
        for (int i = 0; i < nbrAquatics; i++) {
            aquaticAnimals[i].swim();
        }
    }

    public float maxPenguinSwimmingDepth() {
        float max = 0;
        for (int i = 0; i < nbrAquatics; i++) {
            if (aquaticAnimals[i] instanceof Penguin) {
                Penguin p = (Penguin) aquaticAnimals[i];
                if (p.getSwimmingDepth() > max) {
                    max = p.getSwimmingDepth();
                }
            }
        }
        return max;
    }

    public void displayNumberOfAquaticsByType() {
        int nbrDolphins = 0;
        int nbrPenguins = 0;
        for (int i = 0; i < nbrAquatics; i++) {
            if (aquaticAnimals[i] instanceof Dolphin) {
                nbrDolphins++;
            } else if (aquaticAnimals[i] instanceof Penguin) {
                nbrPenguins++;
            }
        }
        System.out.println("Nombre de dauphins : " + nbrDolphins);
        System.out.println("Nombre de pingouins : " + nbrPenguins);
    }
}
