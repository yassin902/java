// Instruction 34.1 : exception personnalisee levee quand l'age est negatif
public class InvalidAgeException extends Exception {

    public InvalidAgeException() {
        super("Age d'animal invalide : l'age ne peut pas etre negatif.");
    }

    public InvalidAgeException(String message) {
        super(message);
    }
}
