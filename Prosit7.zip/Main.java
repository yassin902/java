public class Main {

    // Tente d'ajouter un animal. Le try/catch permet au programme de
    // continuer meme si addAnimal leve une exception. Le finally affiche
    // le nombre d'animaux apres chaque tentative (reussie ou non).
    private static void tryToAdd(Zoo zoo, Animal animal) {
        try {
            zoo.addAnimal(animal);
            System.out.println(animal.getName() + " a ete ajoute.");
        } catch (ZooFullException e) {
            System.out.println("Erreur : " + e.getMessage());
        } catch (InvalidAgeException e) {
            System.out.println("Erreur : " + e.getMessage());
        } finally {
            System.out.println("Nombre d'animaux dans le zoo : " + zoo.getNbrAnimals());
        }
    }

    public static void main(String[] args) {
        // Instruction 33.3 : nombre de cages reduit a 3
        Zoo myZoo = new Zoo("Belvedere", "Tunis", 3);

        Animal lion = new Animal("Felidae", "Simba", 8, true);
        Animal badAge = new Animal("Canidae", "Rex", -2, true);
        Animal tiger = new Animal("Felidae", "Sherkhan", 6, true);
        Animal dolphin = new Dolphin("Delphinidae", "Flipper", 5, true, "Ocean", 25.5f);
        Animal penguin = new Penguin("Spheniscidae", "Pingu", 3, false, "Antarctique", 20f);

        // Instruction 34.4 : un animal valide
        System.out.println("--- Animal valide ---");
        tryToAdd(myZoo, lion);

        // Instruction 34.4 : un animal avec un age negatif
        System.out.println("--- Age negatif ---");
        tryToAdd(myZoo, badAge);

        // Instruction 34.4 : plusieurs ajouts jusqu'a la capacite maximale
        System.out.println("--- Ajouts jusqu'a la capacite maximale ---");
        tryToAdd(myZoo, tiger);
        tryToAdd(myZoo, dolphin);
        tryToAdd(myZoo, penguin);   // le zoo est plein -> ZooFullException

        System.out.println("--- Fin normale du programme ---");
    }
}
