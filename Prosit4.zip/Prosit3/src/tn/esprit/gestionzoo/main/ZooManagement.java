package tn.esprit.gestionzoo.main;

import tn.esprit.gestionzoo.entities.Animal;
import tn.esprit.gestionzoo.entities.Zoo;

public class ZooManagement {

    public static void main(String[] args) {

        Animal lion = new Animal("Felidae", "Simba", 5, true);
        Animal snake = new Animal("Reptile", "Kaa", 3, false);
        Animal elephant = new Animal("Elephantidae", "Dumbo", 10, true);

        Zoo myZoo = new Zoo("myZoo", "Tunis");

        System.out.println("Ajout de Simba : " + myZoo.addAnimal(lion));
        System.out.println("Ajout de Kaa : " + myZoo.addAnimal(snake));
        System.out.println("Ajout de Dumbo : " + myZoo.addAnimal(elephant));

        System.out.println();

        myZoo.displayZoo();

        System.out.println();

        System.out.println("Liste des animaux :");
        myZoo.displayAnimals();

        System.out.println();

        int index = myZoo.searchAnimal("Simba");
        System.out.println("Indice de Simba : " + index);

        Animal lion2 = new Animal("Felidae", "Simba", 5, true);

        int index2 = myZoo.searchAnimal(lion2.getName());
        System.out.println("Indice de lion2 : " + index2);

        System.out.println();

        System.out.println("Ajout de lion2 : " + myZoo.addAnimal(lion2));

        System.out.println();

        System.out.println("Suppression de Kaa : " + myZoo.removeAnimal(snake));

        System.out.println("Animaux restants :");
        myZoo.displayAnimals();

        System.out.println();

        Zoo zoo2 = new Zoo("Zoo2", "Sfax");

        zoo2.addAnimal(new Animal("Canidae", "Rex", 4, true));
        zoo2.addAnimal(new Animal("Felidae", "Mia", 2, true));
        zoo2.addAnimal(new Animal("Reptile", "Nagini", 6, false));
        zoo2.addAnimal(new Animal("Aves", "Rio", 3, false));

        System.out.println("Zoo 1 :");
        myZoo.displayZoo();

        System.out.println("Zoo 2 :");
        zoo2.displayZoo();

        Zoo biggestZoo = Zoo.comparerZoo(myZoo, zoo2);

        System.out.println();
        System.out.println("Le zoo qui contient le plus d'animaux est : "
                + biggestZoo.getName());
    }
}