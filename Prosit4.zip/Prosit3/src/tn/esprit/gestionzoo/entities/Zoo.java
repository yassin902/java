package tn.esprit.gestionzoo.entities;

public class Zoo {

    private static final int MAX_CAGES = 25;

    private Animal[] animals;
    private String name;
    private String city;
    private final int nbrCages;
    private int nbrAnimals;

    public Zoo(String name, String city) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Le nom du zoo ne doit pas être vide.");
        }

        this.name = name;
        this.city = city;
        this.nbrCages = MAX_CAGES;
        this.animals = new Animal[MAX_CAGES];
        this.nbrAnimals = 0;
    }

    public boolean addAnimal(Animal animal) {

        if (isZooFull()) {
            return false;
        }

        if (searchAnimal(animal.getName()) != -1) {
            return false;
        }

        animals[nbrAnimals] = animal;
        nbrAnimals++;

        return true;
    }

    public void displayAnimals() {

        if (nbrAnimals == 0) {
            System.out.println("Le zoo ne contient aucun animal.");
            return;
        }

        for (int i = 0; i < nbrAnimals; i++) {
            System.out.println("tn.esprit.gestionzoo.entities.Animal " + i + " : " + animals[i]);
        }
    }

    public int searchAnimal(String name) {

        for (int i = 0; i < nbrAnimals; i++) {
            if (animals[i].getName().equals(name)) {
                return i;
            }
        }

        return -1;
    }

    public boolean removeAnimal(Animal animal) {

        int index = searchAnimal(animal.getName());

        if (index == -1) {
            return false;
        }

        for (int i = index; i < nbrAnimals - 1; i++) {
            animals[i] = animals[i + 1];
        }

        animals[nbrAnimals - 1] = null;
        nbrAnimals--;

        return true;
    }

    public boolean isZooFull() {
        return nbrAnimals >= nbrCages;
    }

    public static Zoo comparerZoo(Zoo zoo1, Zoo zoo2) {

        if (zoo1.nbrAnimals > zoo2.nbrAnimals) {
            return zoo1;
        } else {
            return zoo2;
        }
    }

    public void displayZoo() {
        System.out.println(
                "Nom du zoo : " + name +
                        " | Ville : " + city +
                        " | Nombre de cages : " + nbrCages +
                        " | Nombre d'animaux : " + nbrAnimals
        );
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Le nom du zoo ne doit pas être vide.");
        }
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getNbrCages() {
        return nbrCages;
    }

    public int getNbrAnimals() {
        return nbrAnimals;
    }

    @Override
    public String toString() {
        return "tn.esprit.gestionzoo.entities.Zoo{" +
                "name='" + name + '\'' +
                ", city='" + city + '\'' +
                ", nbrCages=" + nbrCages +
                ", nbrAnimals=" + nbrAnimals +
                '}';
    }
}